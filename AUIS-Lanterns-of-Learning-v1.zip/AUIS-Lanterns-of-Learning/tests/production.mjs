import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--enable-webgl','--ignore-gpu-blocklist']});
const page=await browser.newPage({viewport:{width:1440,height:900},deviceScaleFactor:1});
const errors=[],checks=[],failures=[];
page.on('pageerror',e=>errors.push(e.message));
await page.addInitScript(()=>{const NativeAudio=window.AudioContext;window.AudioContext=class extends NativeAudio{constructor(...args){super(...args);window.__lastAudioContext=this;}};});
await page.goto(process.env.GAME_URL||'http://127.0.0.1:4173/',{waitUntil:'networkidle'});
await page.waitForFunction(()=>window.__AUIS_GAME__?.world?.debug);
const check=async(name,fn)=>{try{await fn();checks.push(name);console.log('PASS',name);}catch(e){failures.push({name,error:e.message});console.log('FAIL',name,e.message);}};
await check('Production build and bundled fonts render',async()=>{assert.ok(await page.locator('#world canvas').count());assert.equal(await page.evaluate(()=>document.fonts.check('16px "DM Sans"')),true);assert.equal(await page.evaluate(()=>document.fonts.check('16px "Libre Caslon Display"')),true);});
await page.locator('#begin').click();
const targets=await page.evaluate(()=>window.__AUIS_GAME__.world.debug.targets.filter(t=>['faculty','support','activity'].includes(t.type)));
for(const target of targets){await check(`Approach and interact: ${target.id}`,async()=>{
 const found=await page.evaluate(t=>{const w=window.__AUIS_GAME__.world;const options=[];for(const d of [.6,1,1.8,2.6,3.2])for(let i=0;i<8;i++)options.push({x:t.x+Math.cos(i*Math.PI/4)*d,z:t.z+Math.sin(i*Math.PI/4)*d});for(const p of options){if(!w.debug.canStand(p.x,p.z))continue;w.testMove(p);if(window.__AUIS_GAME__.target?.id===t.id)return true;}return false;},target);
 assert.ok(found,'target has no reachable nearest interaction position');await page.keyboard.press('e');await page.getByRole('dialog').waitFor();const dialog=await page.locator('.modal-header h2').innerText();assert.ok(dialog.length>2);if(target.type==='faculty')assert.ok(dialog.includes(target.name.split(' ·')[0]));if(target.type==='activity')assert.ok(await page.locator('.activity-shell').count());await page.keyboard.press('Escape');});}
await check('Original music starts and stops after user gesture',async()=>{await page.locator('#audio-toggle').click();assert.equal(await page.evaluate(()=>window.__lastAudioContext?.state),'running');assert.equal(await page.evaluate(()=>window.__AUIS_GAME__.state.settings.music),true);await page.locator('#audio-toggle').click();assert.equal(await page.evaluate(()=>window.__AUIS_GAME__.state.settings.music),false);});
await check('Camera settings, modal focus, and movement pause remain usable',async()=>{await page.locator('[data-menu="settings"]').click();await page.locator('#sensitivity').evaluate(e=>{e.value='1.8';e.dispatchEvent(new Event('change',{bubbles:true}));});const before=await page.evaluate(()=>window.__AUIS_GAME__.world.getPosition());await page.keyboard.down('w');await page.waitForTimeout(200);await page.keyboard.up('w');assert.deepEqual(await page.evaluate(()=>window.__AUIS_GAME__.world.getPosition()),before);await page.keyboard.press('Tab');assert.ok(await page.evaluate(()=>!!document.activeElement.closest('.modal')));await page.keyboard.press('Escape');});
const gpu=await page.evaluate(()=>{const gl=window.__AUIS_GAME__.world.renderer.getContext();const e=gl.getExtension('WEBGL_debug_renderer_info');return e?{vendor:gl.getParameter(e.UNMASKED_VENDOR_WEBGL),renderer:gl.getParameter(e.UNMASKED_RENDERER_WEBGL)}:{renderer:gl.getParameter(gl.RENDERER)};});
const performance=[];
for(const region of ['village','engineering','computing','mathematics']){await page.evaluate(id=>window.__AUIS_GAME__.world.teleport(id),region);await page.waitForTimeout(1600);performance.push({region,deviceScale:1,metrics:await page.evaluate(()=>window.__AUIS_GAME__.metrics)});}
await page.evaluate(()=>window.__AUIS_GAME__.world.teleport('village'));await page.waitForTimeout(700);await page.screenshot({path:'public/screenshots/08-production-village.png'});
await page.close();
const retina=await browser.newPage({viewport:{width:1440,height:900},deviceScaleFactor:2});
retina.on('pageerror',e=>errors.push(e.message));
await retina.goto(process.env.GAME_URL||'http://127.0.0.1:4173/',{waitUntil:'networkidle'});await retina.waitForFunction(()=>window.__AUIS_GAME__?.world);for(const quality of ['high','balanced']){await retina.evaluate(q=>window.__AUIS_GAME__.world.setSettings({quality:q}),quality);await retina.waitForTimeout(2200);const samples=[];for(let i=0;i<4;i++){samples.push(await retina.evaluate(()=>window.__AUIS_GAME__.metrics));await retina.waitForTimeout(400);}performance.push({region:'village',deviceScale:2,quality,samples});}
await retina.close();
await check('Production has no browser runtime errors',async()=>assert.deepEqual(errors,[]));
const report={browser:'Google Chrome '+browser.version(),device:'MacBook Pro18,3 / Apple M1 Pro / 16 GB',gpu,testedAt:new Date().toISOString(),checks,failures,errors,performance};await writeFile('docs/production-results.json',JSON.stringify(report,null,2)+'\n');await browser.close();console.log(JSON.stringify(report,null,2));if(failures.length)process.exitCode=1;
