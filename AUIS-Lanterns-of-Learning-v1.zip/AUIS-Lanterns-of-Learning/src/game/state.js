const KEY = 'auis-lanterns-v1';
const defaults = () => ({version:1, completed:[], discovered:['village'], position:null, welcomed:false, region:'village', settings:{music:false, quality:'high', sensitivity:1, reducedMotion:false}, savedAt:null});
const validIds = ['intro','bridge','energy','commands','market','story','samples','council','light','tooth','ingredients'];
export function loadState(){
  try {const raw=JSON.parse(localStorage.getItem(KEY)); if(!raw||raw.version!==1)return defaults(); return {...defaults(),...raw, completed:Array.isArray(raw.completed)?raw.completed.filter(id=>validIds.includes(id)):[], discovered:Array.isArray(raw.discovered)?raw.discovered.filter(id=>typeof id==='string'):['village'], settings:{...defaults().settings,...raw.settings}};} catch{return defaults();}
}
export function saveState(state){try {state.savedAt=new Date().toISOString(); localStorage.setItem(KEY,JSON.stringify(state)); return true;} catch{return false;}}
export function resetState(){localStorage.removeItem(KEY);return defaults();}
export function lanternCount(state){const regions=[['bridge','energy'],['commands'],['market'],['story'],['samples'],['council'],['light'],['tooth'],['ingredients']];return regions.filter(ids=>ids.every(id=>state.completed.includes(id))).length;}
export {KEY as SAVE_KEY};
