// Fantasy place names are original. Academic unit IDs link to editable content data.
export const regions = [
  { id: 'village', name: 'Firstlight Village', subtitle: 'A small beginning. A wide horizon.', color: '#f4bd62', x: 0, z: 12, unitId: 'app' },
  { id: 'engineering', name: 'Forge Highlands', subtitle: 'Build what carries us forward.', color: '#eab56f', x: 38, z: -24, unitId: 'engineering' },
  { id: 'computing', name: 'Rune City', subtitle: 'Every mystery has a pattern.', color: '#83cedb', x: 60, z: 21, unitId: 'computing' },
  { id: 'business', name: 'Merchant Coast', subtitle: 'Ideas meet opportunity.', color: '#f0bb82', x: 31, z: 63, unitId: 'business' },
  { id: 'english', name: 'Storywood', subtitle: 'Listen. Every leaf has a story.', color: '#d79ccc', x: -24, z: 57, unitId: 'english' },
  { id: 'medical', name: 'Vitalis Valley', subtitle: 'Observe closely. Care deeply.', color: '#95cdb3', x: -61, z: 24, unitId: 'medical' },
  { id: 'social', name: 'Council Citadel', subtitle: 'Understand the world together.', color: '#aeb1de', x: -58, z: -28, unitId: 'social' },
  { id: 'mathematics', name: 'Astral Peaks', subtitle: 'Follow the light of discovery.', color: '#98bbec', x: -26, z: -64, unitId: 'mathematics' },
  { id: 'dentistry', name: 'Ivory Sanctuary', subtitle: 'Precision in the service of care.', color: '#ead8b4', x: 18, z: -62, unitId: 'dentistry' },
  { id: 'pharmacy', name: 'Alchemist Gardens', subtitle: 'Grow a question. Find an answer.', color: '#bcbae1', x: 58, z: -55, unitId: 'pharmacy' },
];

export const regionById = Object.fromEntries(regions.map(region => [region.id, region]));
