# Lanterns of Learning

An original browser-based, third-person fantasy adventure about discovering AUIS academic fields and restoring a damaged knowledge beacon. Built with Three.js and Vite. The world contains Firstlight Village, seven department regions and two college regions, with eleven interactive activities and ten verified faculty guides.

## Run locally

Use Node.js 18 or newer (Node.js 20+ recommended) and npm.

```sh
npm ci
npm run dev
```

Open the URL printed by Vite, normally `http://127.0.0.1:5173/`. The game starts directly in its 3D world. Press **Begin your journey** to dismiss the introduction.

```sh
npm run build
npm run preview
```

`dist/` is the complete production build: serve it using any static HTTP host. Opening `index.html` through `file://` does not support the JavaScript module/assets path used by the build. No server database, authentication or API keys are required. All fonts, graphics and game code are included; official academic links open AUIS in another tab.

## Play

| Control | Action |
| --- | --- |
| WASD or arrow keys | Walk relative to the camera |
| Shift | Run |
| Space | Jump |
| Mouse drag, left or right | Orbit camera |
| Mouse wheel | Zoom |
| Q / R | Rotate camera with keyboard |
| E | Talk to a nearby character or interact with an object |
| M / J / L | World map / quest journal / Moulakis Archive |
| Escape | Close a panel |

On touch devices, use the directional pad, Jump and Talk buttons; drag the world to turn the camera. Graphics quality, camera sensitivity, reduced motion and original music are adjustable in Settings. Touch layout is supported; native touch hardware and all mobile GPUs have not been benchmarked.

Start with Sera in the village, then follow the east trail to Professor Switzner at the river crossing. Repair the bridge by testing a beam material, supports and deck sections. Cross to Professor Al-Waeli and restore solar power. Completing both Forge tasks restores the first of nine academic lanterns. Explore the other regions, learn from their guides and complete their activities. The completed beacon gives the final story reward.

The map unlocks fast travel after discovering a region on foot. Interactions are short; choose **Tell me about this field** for factual academic information or open its archive entry. Returning to a guide after a successful activity gives feedback. Completed activities can be replayed without duplicate rewards.

Progress, discoveries, player position and settings are automatically saved in this browser’s `localStorage`, under `auis-lanterns-v1`. Settings also offers manual saving and a confirmed reset. Saves stay on the current device/browser; clearing browser site data clears them.

## Content, sources and assets

- [Editing and extension guide](docs/CONTENT_GUIDE.md): characters, facts, regions and new activities.
- [Academic source register](docs/ACADEMIC_SOURCES.md): official URLs, faculty verification and classification notes.
- [Release status](docs/RELEASE_STATUS.md): complete areas and follow-up scope.
- [Browser test report](docs/TEST_REPORT.md): results, device, performance and screenshots.
- [Asset register](docs/ASSETS.md): original procedural geometry/audio, font and dependency licenses.

Academic records are in `src/data/academics.js`, with official source URLs and verification date **2026-10-06**. All fantasy locations, characters other than identified faculty, dialogue, music, quests and visual designs are original. Faculty fantasy roles, appearances and dialogue are explicitly fictional adaptations, without invented histories, quotations or endorsements. The game is an educational adaptation, not an official university product.

The overview claims eight departments while linking seven departments and two colleges. The current academic directory and 2025–26 catalog support seven. The game records the unresolved discrepancy instead of inventing an eighth department. APP remains a preparatory program, the library remains a library, and minors are not displayed as degrees.

## Browser checks

The repeatable browser test uses installed Google Chrome:

```sh
npm run dev
# In another terminal:
npm run test:browser
# For additional character approach/music/Retina checks against a running production preview:
node tests/production.mjs
```

Set `GAME_URL` to test another local/hosted build. On a platform without installed Chrome, install Chrome or change `chromium.launch({ channel: 'chrome' })` in `tests/browser.mjs` to a Playwright Chromium launch after `npx playwright install chromium`. The test performs real keyboard/mouse inputs and activity controls. Its documented debug bridge positions the explorer for repeatable checks; successful quests are always completed through the puzzle UI. It writes `docs/browser-results.json` and `public/screenshots/`.
