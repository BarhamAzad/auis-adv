# Asset register

The release contains original procedural assets rather than copyrighted game assets.

| Asset | Location | Origin / license |
| --- | --- | --- |
| Terrain, trees, flowers, cottages, bridges, workshop machinery, regional architecture, ruins, explorer and NPC geometry | `src/game/world.js` | Original geometry authored for this project |
| Character walk/run/jump and ambient animations | `src/game/world.js` | Original procedural animation |
| Gentle sixteen-note melody, synthesized tones and reward chime | `src/game/audio.js` | Original composition and Web Audio synthesis |
| Functional puzzle schematics | `src/game/activities.js` | Original SVG scientific/learning diagrams |
| Map and minimap | `src/main.js` | Original functional SVG maps derived from world coordinates |
| Lantern favicon | `public/favicon.svg` | Original vector mark |
| DM Sans fonts | `public/fonts/dm-sans-*.ttf` | SIL Open Font License; included `DM-Sans-OFL.txt` |
| Libre Caslon Display | `public/fonts/libre-caslon-display.ttf` | SIL Open Font License; included `Libre-Caslon-Display-OFL.txt` |
| Interface icons | `lucide` package | ISC license; npm package license included in dependencies |
| 3D rendering engine | `three` package | MIT license |

Typeface sources: Google Fonts official distribution (`fonts.gstatic.com`), with license texts from the Google Fonts repository. No external font or image request is needed at runtime. Official source links intentionally navigate to AUIS when clicked.

Screenshots in `public/screenshots/` are captures of the running game and its interfaces. Academic names and paraphrased facts are attributed through official links in the archive and source register. No faculty portrait photographs, recorded voices, third-party music, Zelda names, artwork, maps, characters or assets are used.
