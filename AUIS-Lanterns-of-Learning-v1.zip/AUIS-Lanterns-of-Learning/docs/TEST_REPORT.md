# Browser verification

The game was exercised in installed Google Chrome using Playwright with a real WebGL canvas. The acceptance script uses real keyboard and mouse actions, form controls and puzzle test buttons. Debug navigation places the explorer at repeatable locations; it never directly awards quest completion.

## Browser and device

- Google Chrome **154.0.8037.98**, headless browser automation.
- **MacBook Pro (MacBookPro18,3), Apple M1 Pro, 8-core CPU, 16 GB memory**.
- **macOS 15.5**, ARM64.
- Desktop viewport **1440 × 900**, device scale **1**.
- Responsive layout also inspected at **390 × 844**. Retina checks used device scale **2**, rendering at **2592 × 1620** (High) and **1655 × 1035** (Balanced).
- Chrome reported **ANGLE Metal Renderer: Apple M1 Pro**, confirming the hardware-backed WebGL renderer.
- Both High and Balanced graphics presets measured after a warm-up period. A single device cannot establish performance on other machines or native mobile browsers.

## Measured performance

Warmed samples measured **60 FPS** in Firstlight Village, Forge approach, Rune City and Astral Peaks at 1440 × 900. The Retina village samples also measured **60 FPS** in both presets. Village draw calls fell from roughly **470** in the initial implementation to **143** after batching scenery and characters. The sampled regional views used **52–143 draw calls** and approximately **122,000–140,000 triangles**.

These are short stationary warmed samples on one device, not sustained-load or minimum-device benchmarks. Machine-readable samples and the actual GPU string are in `docs/production-results.json`.

## Acceptance coverage

The main repeatable script is `tests/browser.mjs`; machine-readable output is `docs/browser-results.json`. **All 27 acceptance checks passed.** `tests/production.mjs` additionally verifies **32 individual character/activity approach-and-E interactions**, bundled fonts, original music starting/stopping after a gesture, camera settings, focus/movement pause and runtime errors: **36 additional checks passed**. Both were run against the production build.

It verifies startup, walking versus running, jump and landing, orbit and zoom, camera above terrain, solid-building collision, blocked river crossing before repair, nearby E conversations, optional facts and hints, unsuccessful attempts, all eleven successful activity solutions, bridge opening, first Forge lantern, nine-lantern beacon ending, duplicate reward prevention, all region guides/support/activity targets, walkable fast-travel arrivals, archive classifications and source audit, map/journal shortcuts, completed quest records, saved progress/position/settings across reload, confirmed reset, responsive panels, and absence of browser runtime errors.

Initial village and Forge checks passed before the expanded-world acceptance. A first archive assertion incorrectly expected uppercase text while the data contained lowercase `college`; the assertion was corrected to compare case-insensitively. No academic classification was changed.

## Screenshots

| Capture | File |
| --- | --- |
| Starting village and animated explorer | [01-firstlight-village.png](../public/screenshots/01-firstlight-village.png) |
| Forge Highlands after bridge restoration | [02-forge-highlands.png](../public/screenshots/02-forge-highlands.png) |
| Solar activity, successful output and reward | [03-energy-discovery.png](../public/screenshots/03-energy-discovery.png) |
| Interactive ray-reflection puzzle | [04-astral-light-puzzle.png](../public/screenshots/04-astral-light-puzzle.png) |
| Completed beacon story reward | [05-beacon-restored.png](../public/screenshots/05-beacon-restored.png) |
| Sourced Moulakis Archive | [06-moulakis-archive.png](../public/screenshots/06-moulakis-archive.png) |
| Packaged game, clear paths and interaction markers | [08-production-village.png](../public/screenshots/08-production-village.png) |
| Small-screen archive | [07-mobile-archive.png](../public/screenshots/07-mobile-archive.png) |

## Scope limits

This release has been accepted in Chrome on the device above. Firefox, Safari, native mobile hardware, game controllers, screen-reader playability and long sessions have not been separately benchmarked. Camera collision coverage is a compact terrain/building-volume model. Regional tests verify landmarks and walkable arrivals, rather than exhaustively traversing every possible route. Activity models intentionally simplify their academic subjects.

The first few frames can be slower while Chrome compiles shaders. The performance sample is a short, warmed stationary view; it is not a long-session percentile benchmark. Reduce graphics quality if a device struggles. Local saves are device-specific and may fail if the browser blocks storage; manual Save reports failure.
