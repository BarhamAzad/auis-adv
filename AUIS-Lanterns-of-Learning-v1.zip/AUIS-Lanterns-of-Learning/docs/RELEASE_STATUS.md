# Release status

## First release checkpoint

Firstlight Village and Forge Highlands were tested in installed Google Chrome before the full-world acceptance pass: animated player, walking/running/jumping, orbit and zoom, solid building/river collisions, Sera conversation, verified Switzner and Al-Waeli conversations, study-skills introduction, bridge design, solar-energy system, repaired crossing, powered workshop, first knowledge lantern, and saved progress.

## Expanded release

| Area | Academic classification | Guides and support | Playable activity | Status |
| --- | --- | --- | --- | --- |
| Firstlight Village | Academic Preparatory Program | Sera, Mira | Investigation sequence | Complete |
| Forge Highlands | Engineering department | Nathaniel Switzner, Ali H. A. Al-Waeli, workshop assistant | Bridge and solar collector | Complete |
| Rune City | Computing and Informatics department | Hoger Mahmud, local companion | Program and debug Pip | Complete |
| Merchant Coast | Business Administration department | Fahrettin Sümer, merchant | Allocate a market budget | Complete |
| Storywood | English department | Choman Hardi, reporter | Evaluate conflicting reports | Complete |
| Vitalis Valley | Medical & Health Sciences department | Mohanad Nada, researcher | Compare simulated microscope samples | Complete |
| Council Citadel | Social Sciences and Law department | Robert Perrins, archivist | Negotiate water sharing | Complete |
| Astral Peaks | Mathematics and Natural Sciences department | Dastan Khalid, observer | Redirect a reflected beam | Complete |
| Ivory Sanctuary | College of Dentistry | Tara Ali Rasheed, assistant | Assemble tooth structures | Complete |
| Alchemist Gardens | College of Pharmacy | Mohammed Nawzad Sabir, botanist | Classify imaginary ingredients and formulate fictional ink | Complete |

World map, discovered-region fast travel, short conversations with deeper academic explanations, quest journal, sourced Moulakis Archive, settings, original synthesized music and device-local persistence are complete. Both Forge tasks contribute one engineering lantern; APP introduces study skills but does not count as a department or a beacon lantern.

## Remaining work and practical limits

No world-plan area is left as a placeholder. Each academic region has at least one playable activity; the additional suggested activities in the brief are expansion ideas, not all implemented as separate quests. The compact first release has one study-skills activity, two Forge activities and one activity per other academic region.

Possible further development includes additional quests per region, controller remapping, authored character clips, a larger geography, cross-device saves, native mobile touch/GPU testing, Firefox/Safari acceptance runs, and a full accessibility playtest. The current game uses a low-poly procedural art style, articulated limb animation, a fixed golden-hour lighting setup, and a compact open world. Laboratory and pharmacy tasks are simplified fictional teaching models.

The official eight-versus-seven department discrepancy remains unresolved and documented. This release is not a complete admissions catalog; official AUIS pages remain authoritative for current offerings.
